﻿double x = 0.7;
double expX = Math.Exp(x);
double cosExpX = Math.Cos(expX);

if (cosExpX <= 0)
{
    Console.WriteLine("Ошибка: cos(e^x) меньше или равен нулю, логарифм не определен.");
    return;
}

double lnCosExpX = Math.Log(cosExpX);

double sinXCubed = Math.Pow(Math.Sin(x), 3);

double absTerm = Math.Abs(1 - Math.Pow(x, 2));

double denominator = Math.Sqrt(sinXCubed + absTerm);
if (denominator <= 0)
{
    Console.WriteLine("Ошибка: знаменатель меньше или равен нулю.");
    return;
}

double y = 20 * lnCosExpX - 2 / denominator;

Console.WriteLine($"Значение функции y при x = {x}: {y}");
