﻿Console.WriteLine("Введите три целых числа:");
int num1 = Convert.ToInt32(Console.ReadLine());
int num2 = Convert.ToInt32(Console.ReadLine());
int num3 = Convert.ToInt32(Console.ReadLine());

int sum = num1 + num2 + num3;
Console.WriteLine($"Сумма чисел: {sum}");
