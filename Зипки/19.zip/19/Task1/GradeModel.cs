﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentDiary
{
    public class GradeModel
    {
        public string Subject { get; set; }
        public int Grade { get; set; }
        public DateTime Date { get; set; }
    }

}
