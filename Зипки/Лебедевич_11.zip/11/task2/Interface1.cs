﻿namespace task2
{
    public interface IPaymentStrategy
    {
        void Pay(decimal amount);
    }
}
