﻿namespace task3
{
    public interface IChatUser
    {
        void Update(string message);
    }
}
