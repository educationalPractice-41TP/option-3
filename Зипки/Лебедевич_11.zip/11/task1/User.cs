﻿namespace task1
{
    public class User
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
