﻿using task1;

namespace task1
{
    public abstract class CharacterFactory
    {
        public abstract ICharacter CreateCharacter();
    }
}

//qwodkqwd?

