﻿namespace task1
{
    public interface ICharacter
    {
        void Attack();
    }
}
