﻿namespace task2
{
    public interface IWeapon
    {
        string GetDescription();
        int GetDamage();
    }
}
