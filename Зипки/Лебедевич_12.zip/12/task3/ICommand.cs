﻿namespace task3
{
    public interface ICommand
    {
        void Execute();
        void Undo();
    }
}
