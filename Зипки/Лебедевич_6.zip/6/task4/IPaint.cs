﻿namespace task4
{
    public interface IPaint
    {
        void ApplyColor(string color);
    }
}
