﻿namespace task4
{
    public interface IDraw
    {
        void ApplyColor(string color);
    }
}
