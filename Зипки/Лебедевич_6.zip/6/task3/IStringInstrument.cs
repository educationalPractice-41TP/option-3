﻿namespace task3
{
    public interface IStringInstrument
    {
        void PluckStrings();
    }
}
