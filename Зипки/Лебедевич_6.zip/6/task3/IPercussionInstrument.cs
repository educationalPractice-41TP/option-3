﻿namespace task3
{
    public interface IPercussionInstrument
    {
        void Hit();
    }
}
