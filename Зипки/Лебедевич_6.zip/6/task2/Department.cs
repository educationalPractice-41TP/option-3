﻿namespace task2
{

    public class Department
    {
        public string Title { get; }

        public Department(string title)
        {
            Title = title;
        }
    }
}
