﻿namespace task2
{
    public class Professor
    {
        public string Name { get; }

        public Professor(string name)
        {
            Name = name;
        }
    }
}
