﻿namespace task2
{
    public class Student
    {
        public string Name { get; }

        public Student(string name)
        {
            Name = name;
        }
    }
}
