﻿namespace task1 { 
    public abstract class Shape
    {
        public abstract double GetArea();
    }
}
