﻿namespace task3
{
    public sealed class Developer : Employee
    {
        public Developer(string name, int age, decimal salary)
            : base(name, age, salary)
        {
        }
    }
}