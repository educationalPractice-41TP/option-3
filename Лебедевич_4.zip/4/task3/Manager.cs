﻿namespace task3
{
    public sealed class Manager : Employee
    {
        public Manager(string name, int age, decimal salary)
            : base(name, age, salary)
        {
        }
    }
}